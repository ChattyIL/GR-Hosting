Version Date: 2024-06-28 00:06:46 

 Extract and place these files in a folder called 'vg-build' in the root public directory of your website, ensure it is working by trying to access the styles.css (https://yourdomain.com/vg-build/styles.css)